/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab12c;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author rrgm1
 */
public class Lab12c {

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException {
        File JUMP = new File ("words2.txt");
        
        Scanner scnr = new Scanner (JUMP);
        Scanner input = new Scanner (System.in);
        
        while (scnr.hasNext()) {
            System.out.println(scnr.next());
        }
    }
    
}
