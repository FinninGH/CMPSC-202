/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package labfornov4;

import java.util.Scanner;

/**
 *
 * @author rrgm1
 */
public class LabForNov4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scnr = new Scanner (System.in);
        Character[] letters = new Character[5];
        String input = scnr.next();
        int length = input.length();
        String vowels = "";
        
        for (int c = 0; c < length; c++) {
            letters[c] = input.charAt(c);
        }
        
        for (int h = 0; h < length; h++) {
           switch (letters[h]){
               case 'a':
               case 'e':
               case 'i':
               case 'o':
               case 'u':
                   vowels = vowels + letters[h];
                   break;
               default:
                   break;
           }
        }
        System.out.println(vowels);
    }
    
}
