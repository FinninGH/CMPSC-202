/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tictactoe;

import java.util.Scanner;

/**
 *
 * @author rrgm1
 */
public class TicTacToe {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
            
        //gameplay code before
        char [] [] board = createBoard();
        int turn = 1;
        Boolean p1Turn = true;
        Character input;
        Boolean victory = false;
        Scanner scnr = new Scanner(System.in);
        
        printBoard(board);
        
        for (int i = 1; i <= 9; i++){
                //switch statement depending on input, in switch do if/else to tell whose turn it is
            System.out.println("Turn " + turn);
            if (p1Turn == true) {
                System.out.println("Player one's Turn (X)");
            }
            else {
                System.out.println("Player two's Turn (O)");
            }
            String temp = scnr.next();
            input = temp.charAt(0);
            
            markBoard(input, p1Turn, board);
            printBoard(board);
            
            victory = checkVictory(board);
            
            if (victory == true) {
                if (p1Turn == true){
                    System.out.println("Player 1 wins! Congratulations!");
                    break;
                }
                else {
                    System.out.println("Player 2 wins! Congratulations!");
                    break;
                }
            }
            
            if (p1Turn == true){
                p1Turn = false;
            }
            else{
                p1Turn = true;
            }
        }
        if (victory == false) {
            System.out.println("It's a draw!");
        }
    }
    
    public static char [] [] createBoard() {
        char [] [] board = new char [17] [17];
        
        //outline the board
        for (int col = 0; col < 17; col++) {
            for (int row = 0; row < 17; row ++) {
		board [row] [col] = ' ';
            }
        }
        for (int row = 0; row < 17; row++) {
	board [row] [5] = '|';
        board [5] [row] = '-';
        board [row] [11] = '|';
        board [11] [row] = '-';
        }
        
        //number the board
        
        board [2] [2] = '1';
        board [2] [8] = '2';
        board [2] [14] = '3';
        board [8] [2] = '4';
        board [8] [8] = '5';
        board [8] [14] = '6';
        board [14] [2] = '7';
        board [14] [8] = '8';
        board [14] [14] = '9';
        

        return board;
    }
    
    public static void printBoard(char [] [] board) {
        //print out the initial board
        for (int col = 0; col < 17; col++) {
            for (int row = 0; row < 17; row ++) {
                System.out.print(board [col] [row]);
            }
        System.out.println();    
        }
    }
    
    public static char [] [] markBoard(Character input, Boolean p1Turn, char [] [] board) {
        switch (input) {
                case '1':
                    if (p1Turn == true) {
                        board [2] [2] = 'X';
                    }
                    else {
                        board [2] [2] = 'O';
                    }
                    break;
                case '2':
                    if (p1Turn == true) {
                        board [2] [8] = 'X';
                    }
                    else {
                        board [2] [8] = 'O';
                    }
                    break;
                case '3':
                    if (p1Turn == true) {
                        board [2] [14] = 'X';
                    }
                    else {
                        board [2] [14] = 'O';
                    }
                    break;
                case '4':
                    if (p1Turn == true) {
                        board [8] [2] = 'X';
                    }
                    else {
                        board [8] [2] = 'O';
                    }
                    break;
                case '5':
                    if (p1Turn == true) {
                        board [8] [8] = 'X';
                    }
                    else {
                        board [8] [8] = 'O';
                    }
                    break;
                case '6':
                    if (p1Turn == true) {
                        board [8] [14] = 'X';
                    }
                    else {
                        board [8] [14] = 'O';
                    }
                    break;
                case '7':
                    if (p1Turn == true) {
                        board [14] [2] = 'X';
                    }
                    else {
                        board [14] [2] = 'O';
                    }
                    break;
                case '8':
                    if (p1Turn == true) {
                        board [14] [8] = 'X';
                    }
                    else {
                        board [14] [8] = 'O';
                    }
                    break;
                case '9':
                    if (p1Turn == true) {
                        board [14] [14] = 'X';
                    }
                    else {
                        board [14] [14] = 'O';
                    }
                    break;
                default:
                    System.out.println("Invalid input. Please input a number 1-9.");
                    break;
            }
            return board;
            }
    
    public static boolean checkVictory(char [] [] board) {
boolean victory = false;
        if (board [2] [2] == board [2] [8] && board [2] [2] == board [2] [14]) {
                victory = true;
            }
            if (board [8] [2] == board [8] [8] && board [8] [2] == board [8] [14]) {
                victory = true;
            }
            if (board [14] [2] == board [14] [8] && board [14] [2] == board [14] [14]) {
                victory = true;
            }
            if (board [2] [2] == board [8] [2] && board [2] [2] == board [14] [2]) {
                victory = true;
            }
            if (board [2] [8] == board [8] [8] && board [2] [8] == board [14] [8]) {
                victory = true;
            }
            if (board [2] [14] == board [8] [14] && board [2] [14] == board [14] [14]) {
                victory = true;
            }
            if (board [2] [2] == board [8] [8] && board [2] [2] == board [14] [14]) {
                victory = true;
            }
            if (board [2] [14] == board [8] [8] && board [2] [14] == board [14] [2]) {
                victory = true;
    }
return victory;
}
}
