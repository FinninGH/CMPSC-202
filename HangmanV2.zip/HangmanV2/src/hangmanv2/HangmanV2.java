/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package hangmanv2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author rrgm1
 */
public class HangmanV2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scnr = new Scanner (System.in);
        String word = ""; //This one's the answer
        String guess; //This one's for the user's guess
        Character guessConv; //The guess variable turned into a string
        String display = ""; //Displays the word in underscores
        int length;
        Boolean win = false;
        Random rndm = new Random ();
        Scanner scn2 = null;
File inFile = new File("words_no_duplicates.txt");
try{
scn2 = new Scanner(inFile);
}
catch(FileNotFoundException e){
System.out.println("Error. File not found.");
}
        
        System.out.println("Let's play some Hangman! Guess the letters to the word you input until you win or lose!");
        System.out.println("You have 10 lives. Don't let them drop to zero!");
        System.out.println("(Do note the word will be in all lowercase)");
        
        System.out.println("---------------------------");
        
        int pick = rndm.nextInt(4581);
        for (int k = 0; k < pick; k++) {
        word = scn2.nextLine();
        }
        length = word.length();
        word = word.toLowerCase(); //Move this when swapping out word selection method
        
        for (int c = 0; c < length; c++) {
            display = display + "_";
        }
        System.out.println(display);
        System.out.println("Enter a letter");
        
        for (int a = 0; a <= 10; a++) {
        
        guess = scnr.next();
        guessConv = guess.charAt(0);
        
        if (word.contains(guess)){
        
        for (int c = 0; c < length; c++) {
            if (guessConv == (word.charAt(c))){
                display = display.substring(0, c) + guess + display.substring(c + 1);
                
            }
        }
        a--;
        }
        
        System.out.println(display);
            System.out.println("Lives: " + (10 - a));
        
        if (display.equals(word)){
            win = true;
            break;
        }
        
        }
        
        System.out.println("Game over!");
        if (win) {
            System.out.println("You win!");
        }
        else {
            System.out.println("You lose!");
        }
        System.out.println("The word was: " + word);
    }
    
}
