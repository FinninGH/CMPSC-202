/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package randnumprac;

import java.util.Random;

/**
 *
 * @author rrgm1
 */
public class RandNumPrac {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int num1s = 0;
        int num2s = 0;
        int num3s = 0;
        int num4s = 0;
        int num5s = 0;
        int num6s = 0;
        int num7s = 0;
        int num8s = 0;
        int num9s = 0;
        int num10s = 0;
        int result;
        Random rand = new Random();
        
        for (int c = 0; c < 100; c++) {
        result = rand.nextInt(10)+1;
        switch (result) {
            case 1:
                num1s++;
                break;
            case 2:
                num2s++;
                break;
            case 3:
                num3s++;
                break;
            case 4:
                num4s++;
                break;
            case 5:
                num5s++;
                break;
            case 6:
                num6s++;
                break;
            case 7:
                num7s++;
                break;
            case 8:
                num8s++;
                break;
            case 9:
                num9s++;
                break;
            case 10:
                num10s++;
                break;
            default:
                break;
        }
            
    }
    System.out.println("1s: " + num1s);
    System.out.println("2s: " + num2s);
    System.out.println("3s: " + num3s);
    System.out.println("4s: " + num4s);
    System.out.println("5s: " + num5s);
    System.out.println("6s: " + num6s);
    System.out.println("7s: " + num7s);
    System.out.println("8s: " + num8s);
    System.out.println("9s: " + num9s);
    System.out.println("10s: " + num10s);
    
}
}
