/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package palinprac;

import java.util.Scanner;

/**
 *
 * @author rrgm1
 */
public class PalinPrac {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);
        String input;
        String flipped = "";
        int length;
        
        input = scnr.nextLine();
        length = input.length();
        
        for (int count = 1; count <= length; count ++) {
        flipped = flipped + input.charAt(length - count);
    }
        if (flipped.equalsIgnoreCase(input)) {
        System.out.println("This is a palindrome");
        }
        else {
            System.out.println("This is not a palindrome");
        }
}
}